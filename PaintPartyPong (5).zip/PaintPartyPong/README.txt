Controls and Setup:
P1 (Red/Left Side): W to move paddle up. S to move paddle down.
P2 (Blue/Right Side): Up arrow to move paddle up. Down arrow to move paddle down.

Make sure the resolution is set to 1920x1080 as it unfortunately doesn't work properly in any other resolutions (sorry!).

Credits:
Lauren Stampoultzis : 101634264 : Design/ Coder
Marc Pagliuca: 101606739: Design / Art / Music and Sound Design
Marco Boshoff: 101624524 : Artist
Michael Nuttall: 101368592 : Coder



As a team, we want to thank Daniel Draper for all of his help with the coding behind the scoring, the painting and fixing any issues with our game 
 and for being a good tutor to us and to other students in need of help.  

We also want to thank Tien Pham for giving good suggestions for the game and guidance in class to us and to other students.

And special thanks to ChilledCow for providing quality low fi hip hop radio beats to relax/study to, for the majority of our classes. 

And to our family and friends, thank you for supporting us this semester!

-TDQ :)